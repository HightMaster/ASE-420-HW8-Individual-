class Command:
    def __init__(self, command):
        self.command = command

    def execute(self):
        pass